<?php
// admin/menu.php
// --- SETUP AWAL ---
include 'header.php';
include '../koneksi.php'; // Asumsi file koneksi berada satu folder di atas

// Tentukan aksi dan ID
$action = $_GET['action'] ?? 'list'; // Aksi default: list
$id     = $_GET['id']     ?? null;
$message = '';

// --- LOGIKA CRUD ---

// 1. CREATE (Tambah Menu)
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['tambah_menu'])) {
    $nama        = $_POST['nama'];
    $deskripsi   = $_POST['deskripsi'];
    $harga       = $_POST['harga'];
    $kategori    = $_POST['kategori'];
    $nama_file   = '';

    // Proses Upload Gambar
    if (isset($_FILES['gambar']) && $_FILES['gambar']['error'] == 0) {
        $target_dir = "../assets/"; // Sesuaikan dengan folder assets kamu
        $file_name  = basename($_FILES['gambar']['name']);
        $target_file = $target_dir . $file_name;

        if (move_uploaded_file($_FILES['gambar']['tmp_name'], $target_file)) {
            $nama_file = $file_name;
        } else {
            $message = '<div class="alert alert-danger">Gagal upload gambar.</div>';
        }
    }

    // Jika belum ada pesan error dari upload
    if (empty($message)) {
        // Prepared Statement INSERT
        $stmt = $Koneksi->prepare("INSERT INTO menu (nama, deskripsi, harga, kategori, gambar) VALUES (?, ?, ?, ?, ?)");
        // 'ssdss' = String, String, Double (atau decimal), String, String
        $stmt->bind_param("sdsds", $nama, $deskripsi, $harga, $kategori, $nama_file);

        if ($stmt->execute()) {
            $message = '<div class="alert alert-success">Menu *' . $nama . '* berhasil ditambahkan!</div>';
        } else {
            $message = '<div class="alert alert-danger">Error: ' . $stmt->error . '</div>';
        }
        $stmt->close();
        $action = 'list';
    }
}

// 2. UPDATE (Edit Menu)
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['edit_menu'])) {
    $id             = $_POST['id'];
    $nama           = $_POST['nama'];
    $deskripsi      = $_POST['deskripsi'];
    $harga          = $_POST['harga'];
    $kategori       = $_POST['kategori'];
    $nama_file_lama = $_POST['gambar_lama'];
    $nama_file_baru = $nama_file_lama; // Default: gunakan nama file lama

    // Proses Upload Gambar Baru
    if (isset($_FILES['gambar']) && $_FILES['gambar']['error'] == 0) {
        $target_dir = "../assets/";
        $file_name  = basename($_FILES['gambar']['name']);
        $target_file = $target_dir . $file_name;

        if (move_uploaded_file($_FILES['gambar']['tmp_name'], $target_file)) {
            $nama_file_baru = $file_name;
            // Opsi: Hapus gambar lama jika ada dan berhasil upload gambar baru
            if (!empty($nama_file_lama) && file_exists($target_dir . $nama_file_lama)) {
                unlink($target_dir . $nama_file_lama);
            }
        } else {
            $message = '<div class="alert alert-danger">Gagal upload gambar baru.</div>';
        }
    }

    // Jika belum ada pesan error
    if (empty($message)) {
        // Prepared Statement UPDATE
        $query = "UPDATE menu SET nama=?, deskripsi=?, harga=?, kategori=?, gambar=? WHERE id=?";
        $stmt = $Koneksi->prepare($query);
        // 'sdsdsi' = String, String, Double, String, String, Integer
        $stmt->bind_param("sdsdsi", $nama, $deskripsi, $harga, $kategori, $nama_file_baru, $id);

        if ($stmt->execute()) {
            $message = '<div class="alert alert-success">Menu *' . $nama . '* berhasil diperbarui.</div>';
        } else {
            $message = '<div class="alert alert-danger">Error: ' . $stmt->error . '</div>';
        }
        $stmt->close();
        $action = 'list';
    }
}

// 3. DELETE (Hapus Menu)
if ($action == 'delete' && isset($id)) {
    // Ambil nama file gambar sebelum dihapus
    $res = $Koneksi->query("SELECT gambar FROM menu WHERE id='$id'");
    $menu_item = $res->fetch_assoc();
    $file_to_delete = $menu_item['gambar'] ?? null;

    // Prepared Statement DELETE
    $stmt = $Koneksi->prepare("DELETE FROM menu WHERE id=?");
    $stmt->bind_param("i", $id); // 'i' = Integer

    if ($stmt->execute()) {
        // Hapus file dari folder assets (opsional, tapi disarankan)
        $path_to_file = "../assets/" . $file_to_delete; // Sesuaikan path

        if (!empty($file_to_delete) && file_exists($path_to_file)) {
            unlink($path_to_file);
        }

        $message = '<div class="alert alert-success">Menu berhasil dihapus.</div>';
    } else {
        $message = '<div class="alert alert-danger">Gagal menghapus menu.</div>';
    }
    $stmt->close();
    $action = 'list';
}

// 4. READ (Ambil Data untuk List atau Edit)
$menus = [];
$menu_data = [];

if ($action == 'list') {
    $res = $Koneksi->query("SELECT * FROM menu ORDER BY kategori, nama");
    $menus = $res->fetch_all(MYSQLI_ASSOC);
} elseif ($action == 'edit' && $id) {
    $res = $Koneksi->query("SELECT * FROM menu WHERE id='$id'");
    $menu_data = $res->fetch_assoc();

    if (!$menu_data) {
        $message = '<div class="alert alert-warning">Data menu tidak ditemukan.</div>';
        $action = 'list';
    }
}
?>

<div class="container mt-4">
    <h1 class="h2">Kelola Menu</h1>
    <hr>

    <?php echo $message; ?>

    <?php if ($action == 'list'): ?>
        <a href="?action=add" class="btn btn-primary mb-3">Tambah Menu Baru</a>
        <div class="table-responsive">
            <table class="table table-striped table-sm">
                <thead>
                    <tr>
                        <th>#ID</th>
                        <th>Gambar</th>
                        <th>Nama</th>
                        <th>Kategori</th>
                        <th>Harga</th>
                        <th>Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($menus as $menu): ?>
                    <tr>
                        <td><?php echo htmlspecialchars($menu['id']); ?></td>
                        <td><img src="../assets/<?php echo htmlspecialchars($menu['gambar']); ?>" alt="<?php echo htmlspecialchars($menu['nama']); ?>" width="50"></td>
                        <td><?php echo htmlspecialchars($menu['nama']); ?></td>
                        <td><?php echo htmlspecialchars($menu['kategori']); ?></td>
                        <td>Rp<?php echo number_format($menu['harga'], 0, ',', '.'); ?></td>
                        <td>
                            <a href="?action=edit&id=<?php echo $menu['id']; ?>" class="btn btn-sm btn-info">Edit</a>
                            <a href="?action=delete&id=<?php echo $menu['id']; ?>" class="btn btn-sm btn-danger" onclick="return confirm('Yakin ingin menghapus menu ini?');">Hapus</a>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>

    <?php elseif ($action == 'add' || $action == 'edit'): ?>
        <h3 class="mt-4"><?php echo $action == 'add' ? 'Tambah' : 'Edit'; ?> Menu</h3>
        
        <form method="POST" action="?action=<?php echo $action; ?>" enctype="multipart/form-data">
            <?php if ($action == 'edit'): ?>
                <input type="hidden" name="id" value="<?php echo htmlspecialchars($menu_data['id'] ?? ''); ?>">
                <input type="hidden" name="gambar_lama" value="<?php echo htmlspecialchars($menu_data['gambar'] ?? ''); ?>">
            <?php endif; ?>

            <div class="form-group">
                <label for="nama">Nama Menu</label>
                <input type="text" class="form-control" id="nama" name="nama" required value="<?php echo htmlspecialchars($menu_data['nama'] ?? ''); ?>">
            </div>

            <div class="form-group">
                <label for="kategori">Kategori</label>
                <select class="form-control" id="kategori" name="kategori" required>
                    <?php $selected_kategori = $menu_data['kategori'] ?? ''; ?>
                    <option value="Minuman" <?php echo $selected_kategori == 'Minuman' ? 'selected' : ''; ?>>Minuman</option>
                    <option value="Makanan" <?php echo $selected_kategori == 'Makanan' ? 'selected' : ''; ?>>Makanan</option>
                </select>
            </div>

            <div class="form-group">
                <label for="deskripsi">Deskripsi</label>
                <textarea class="form-control" id="deskripsi" name="deskripsi" rows="3"><?php echo htmlspecialchars($menu_data['deskripsi'] ?? ''); ?></textarea>
            </div>

            <div class="form-group">
                <label for="harga">Harga (Rp)</label>
                <input type="number" step="0.01" class="form-control" id="harga" name="harga" required value="<?php echo htmlspecialchars($menu_data['harga'] ?? ''); ?>">
            </div>

            <div class="form-group">
                <label for="gambar">Gambar Menu</label>
                <input type="file" class="form-control-file" id="gambar" name="gambar">

                <?php if ($action == 'edit' && !empty($menu_data['gambar'])): ?>
                    <small class="form-text text-muted">Gambar saat ini: *<?php echo htmlspecialchars($menu_data['gambar']); ?>*</small>
                <?php endif; ?>
            </div>

            <button type="submit" name="<?php echo $action == 'add' ? 'tambah_menu' : 'edit_menu'; ?>" class="btn btn-success">Simpan</button>
            <a href="menu.php" class="btn btn-secondary">Batal</a>
        </form>

    <?php endif; ?>
</div>

<?php include 'footer.php'; ?>