<?php

// koneksi.php

$host    = 'localhost';
$user    = 'root'; // Ganti dengan username database kamu
$pass    = '';     // Ganti dengan password database kamu
$db_name = 'toko_kopidap'; // Ganti dengan nama database kamu

$Koneksi = new mysqli($host, $user, $pass, $db_name);

// Cek koneksi
if ($Koneksi->connect_error) {
    die("Koneksi gagal: " . $Koneksi->connect_error);
}

// Data Admin Sederhana (untuk keperluan tutorial)
// DI LINGKUNGAN PRODUKSI, GUNAKAN TABEL USER DAN HASHING PASSWORD!
// GANTI 'ADMIN_PASS' DENGAN PASSWORD YANG LEBIH KUAT!
define('ADMIN_USER', 'admin');
define('ADMIN_PASS', '12345');
?>